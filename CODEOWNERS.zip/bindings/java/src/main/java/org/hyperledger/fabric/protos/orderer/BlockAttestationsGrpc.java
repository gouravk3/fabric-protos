package org.hyperledger.fabric.protos.orderer;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.63.0)",
    comments = "Source: orderer/blockattestation.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class BlockAttestationsGrpc {

  private BlockAttestationsGrpc() {}

  public static final java.lang.String SERVICE_NAME = "orderer.BlockAttestations";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<org.hyperledger.fabric.protos.common.Envelope,
      org.hyperledger.fabric.protos.orderer.BlockAttestationResponse> getBlockAttestationsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "BlockAttestations",
      requestType = org.hyperledger.fabric.protos.common.Envelope.class,
      responseType = org.hyperledger.fabric.protos.orderer.BlockAttestationResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<org.hyperledger.fabric.protos.common.Envelope,
      org.hyperledger.fabric.protos.orderer.BlockAttestationResponse> getBlockAttestationsMethod() {
    io.grpc.MethodDescriptor<org.hyperledger.fabric.protos.common.Envelope, org.hyperledger.fabric.protos.orderer.BlockAttestationResponse> getBlockAttestationsMethod;
    if ((getBlockAttestationsMethod = BlockAttestationsGrpc.getBlockAttestationsMethod) == null) {
      synchronized (BlockAttestationsGrpc.class) {
        if ((getBlockAttestationsMethod = BlockAttestationsGrpc.getBlockAttestationsMethod) == null) {
          BlockAttestationsGrpc.getBlockAttestationsMethod = getBlockAttestationsMethod =
              io.grpc.MethodDescriptor.<org.hyperledger.fabric.protos.common.Envelope, org.hyperledger.fabric.protos.orderer.BlockAttestationResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "BlockAttestations"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  org.hyperledger.fabric.protos.common.Envelope.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  org.hyperledger.fabric.protos.orderer.BlockAttestationResponse.getDefaultInstance()))
              .setSchemaDescriptor(new BlockAttestationsMethodDescriptorSupplier("BlockAttestations"))
              .build();
        }
      }
    }
    return getBlockAttestationsMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static BlockAttestationsStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<BlockAttestationsStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<BlockAttestationsStub>() {
        @java.lang.Override
        public BlockAttestationsStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new BlockAttestationsStub(channel, callOptions);
        }
      };
    return BlockAttestationsStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static BlockAttestationsBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<BlockAttestationsBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<BlockAttestationsBlockingStub>() {
        @java.lang.Override
        public BlockAttestationsBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new BlockAttestationsBlockingStub(channel, callOptions);
        }
      };
    return BlockAttestationsBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static BlockAttestationsFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<BlockAttestationsFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<BlockAttestationsFutureStub>() {
        @java.lang.Override
        public BlockAttestationsFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new BlockAttestationsFutureStub(channel, callOptions);
        }
      };
    return BlockAttestationsFutureStub.newStub(factory, channel);
  }

  /**
   */
  public interface AsyncService {

    /**
     * <pre>
     * BlockAttestations receives an Envelope of type DELIVER_SEEK_INFO , then sends back a stream of BlockAttestations.
     * </pre>
     */
    default void blockAttestations(org.hyperledger.fabric.protos.common.Envelope request,
        io.grpc.stub.StreamObserver<org.hyperledger.fabric.protos.orderer.BlockAttestationResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getBlockAttestationsMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service BlockAttestations.
   */
  public static abstract class BlockAttestationsImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return BlockAttestationsGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service BlockAttestations.
   */
  public static final class BlockAttestationsStub
      extends io.grpc.stub.AbstractAsyncStub<BlockAttestationsStub> {
    private BlockAttestationsStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected BlockAttestationsStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new BlockAttestationsStub(channel, callOptions);
    }

    /**
     * <pre>
     * BlockAttestations receives an Envelope of type DELIVER_SEEK_INFO , then sends back a stream of BlockAttestations.
     * </pre>
     */
    public void blockAttestations(org.hyperledger.fabric.protos.common.Envelope request,
        io.grpc.stub.StreamObserver<org.hyperledger.fabric.protos.orderer.BlockAttestationResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getBlockAttestationsMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service BlockAttestations.
   */
  public static final class BlockAttestationsBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<BlockAttestationsBlockingStub> {
    private BlockAttestationsBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected BlockAttestationsBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new BlockAttestationsBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * BlockAttestations receives an Envelope of type DELIVER_SEEK_INFO , then sends back a stream of BlockAttestations.
     * </pre>
     */
    public java.util.Iterator<org.hyperledger.fabric.protos.orderer.BlockAttestationResponse> blockAttestations(
        org.hyperledger.fabric.protos.common.Envelope request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getBlockAttestationsMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service BlockAttestations.
   */
  public static final class BlockAttestationsFutureStub
      extends io.grpc.stub.AbstractFutureStub<BlockAttestationsFutureStub> {
    private BlockAttestationsFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected BlockAttestationsFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new BlockAttestationsFutureStub(channel, callOptions);
    }
  }

  private static final int METHODID_BLOCK_ATTESTATIONS = 0;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_BLOCK_ATTESTATIONS:
          serviceImpl.blockAttestations((org.hyperledger.fabric.protos.common.Envelope) request,
              (io.grpc.stub.StreamObserver<org.hyperledger.fabric.protos.orderer.BlockAttestationResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getBlockAttestationsMethod(),
          io.grpc.stub.ServerCalls.asyncServerStreamingCall(
            new MethodHandlers<
              org.hyperledger.fabric.protos.common.Envelope,
              org.hyperledger.fabric.protos.orderer.BlockAttestationResponse>(
                service, METHODID_BLOCK_ATTESTATIONS)))
        .build();
  }

  private static abstract class BlockAttestationsBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    BlockAttestationsBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return org.hyperledger.fabric.protos.orderer.BlockattestationProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("BlockAttestations");
    }
  }

  private static final class BlockAttestationsFileDescriptorSupplier
      extends BlockAttestationsBaseDescriptorSupplier {
    BlockAttestationsFileDescriptorSupplier() {}
  }

  private static final class BlockAttestationsMethodDescriptorSupplier
      extends BlockAttestationsBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    BlockAttestationsMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (BlockAttestationsGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new BlockAttestationsFileDescriptorSupplier())
              .addMethod(getBlockAttestationsMethod())
              .build();
        }
      }
    }
    return result;
  }
}
