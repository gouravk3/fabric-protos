package org.hyperledger.fabric.protos.orderer;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * Service ClusterNodeService defines communication between cluster members.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.63.0)",
    comments = "Source: orderer/clusterserver.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class ClusterNodeServiceGrpc {

  private ClusterNodeServiceGrpc() {}

  public static final java.lang.String SERVICE_NAME = "orderer.ClusterNodeService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepRequest,
      org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepResponse> getStepMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Step",
      requestType = org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepRequest.class,
      responseType = org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
  public static io.grpc.MethodDescriptor<org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepRequest,
      org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepResponse> getStepMethod() {
    io.grpc.MethodDescriptor<org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepRequest, org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepResponse> getStepMethod;
    if ((getStepMethod = ClusterNodeServiceGrpc.getStepMethod) == null) {
      synchronized (ClusterNodeServiceGrpc.class) {
        if ((getStepMethod = ClusterNodeServiceGrpc.getStepMethod) == null) {
          ClusterNodeServiceGrpc.getStepMethod = getStepMethod =
              io.grpc.MethodDescriptor.<org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepRequest, org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Step"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ClusterNodeServiceMethodDescriptorSupplier("Step"))
              .build();
        }
      }
    }
    return getStepMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ClusterNodeServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ClusterNodeServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ClusterNodeServiceStub>() {
        @java.lang.Override
        public ClusterNodeServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ClusterNodeServiceStub(channel, callOptions);
        }
      };
    return ClusterNodeServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ClusterNodeServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ClusterNodeServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ClusterNodeServiceBlockingStub>() {
        @java.lang.Override
        public ClusterNodeServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ClusterNodeServiceBlockingStub(channel, callOptions);
        }
      };
    return ClusterNodeServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ClusterNodeServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ClusterNodeServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ClusterNodeServiceFutureStub>() {
        @java.lang.Override
        public ClusterNodeServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ClusterNodeServiceFutureStub(channel, callOptions);
        }
      };
    return ClusterNodeServiceFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * Service ClusterNodeService defines communication between cluster members.
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * Step passes an implementation-specific message to another cluster member.
     * </pre>
     */
    default io.grpc.stub.StreamObserver<org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepRequest> step(
        io.grpc.stub.StreamObserver<org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepResponse> responseObserver) {
      return io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall(getStepMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service ClusterNodeService.
   * <pre>
   * Service ClusterNodeService defines communication between cluster members.
   * </pre>
   */
  public static abstract class ClusterNodeServiceImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return ClusterNodeServiceGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service ClusterNodeService.
   * <pre>
   * Service ClusterNodeService defines communication between cluster members.
   * </pre>
   */
  public static final class ClusterNodeServiceStub
      extends io.grpc.stub.AbstractAsyncStub<ClusterNodeServiceStub> {
    private ClusterNodeServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ClusterNodeServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ClusterNodeServiceStub(channel, callOptions);
    }

    /**
     * <pre>
     * Step passes an implementation-specific message to another cluster member.
     * </pre>
     */
    public io.grpc.stub.StreamObserver<org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepRequest> step(
        io.grpc.stub.StreamObserver<org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepResponse> responseObserver) {
      return io.grpc.stub.ClientCalls.asyncBidiStreamingCall(
          getChannel().newCall(getStepMethod(), getCallOptions()), responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service ClusterNodeService.
   * <pre>
   * Service ClusterNodeService defines communication between cluster members.
   * </pre>
   */
  public static final class ClusterNodeServiceBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<ClusterNodeServiceBlockingStub> {
    private ClusterNodeServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ClusterNodeServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ClusterNodeServiceBlockingStub(channel, callOptions);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service ClusterNodeService.
   * <pre>
   * Service ClusterNodeService defines communication between cluster members.
   * </pre>
   */
  public static final class ClusterNodeServiceFutureStub
      extends io.grpc.stub.AbstractFutureStub<ClusterNodeServiceFutureStub> {
    private ClusterNodeServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ClusterNodeServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ClusterNodeServiceFutureStub(channel, callOptions);
    }
  }

  private static final int METHODID_STEP = 0;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_STEP:
          return (io.grpc.stub.StreamObserver<Req>) serviceImpl.step(
              (io.grpc.stub.StreamObserver<org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepResponse>) responseObserver);
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getStepMethod(),
          io.grpc.stub.ServerCalls.asyncBidiStreamingCall(
            new MethodHandlers<
              org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepRequest,
              org.hyperledger.fabric.protos.orderer.ClusterNodeServiceStepResponse>(
                service, METHODID_STEP)))
        .build();
  }

  private static abstract class ClusterNodeServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    ClusterNodeServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return org.hyperledger.fabric.protos.orderer.ClusterserverProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("ClusterNodeService");
    }
  }

  private static final class ClusterNodeServiceFileDescriptorSupplier
      extends ClusterNodeServiceBaseDescriptorSupplier {
    ClusterNodeServiceFileDescriptorSupplier() {}
  }

  private static final class ClusterNodeServiceMethodDescriptorSupplier
      extends ClusterNodeServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    ClusterNodeServiceMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ClusterNodeServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new ClusterNodeServiceFileDescriptorSupplier())
              .addMethod(getStepMethod())
              .build();
        }
      }
    }
    return result;
  }
}
